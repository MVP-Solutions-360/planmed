import { c as defineEventHandler, e as setHeader, r as readBody } from '../../../_/nitro.mjs';
import { a as assertSameOrigin } from '../../../_/origin.mjs';
import { a as authError, u as useAdminSession, i as isAuthorizedUser, t as toPublicUser, M as MSG_UNAVAILABLE, b as MSG_FORBIDDEN } from '../../../_/auth.mjs';
import { a as wellezyLogin, b as wellezyLogout } from '../../../_/wellezy.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';

const login_post = defineEventHandler(async (event) => {
  assertSameOrigin(event);
  setHeader(event, "Cache-Control", "no-store");
  const body = await readBody(event).catch(() => null);
  const email = typeof (body == null ? void 0 : body.email) === "string" ? body.email.trim() : "";
  const password = typeof (body == null ? void 0 : body.password) === "string" ? body.password : "";
  if (!email || !password || email.length > 255 || password.length > 1024) {
    throw authError(422, "Ingresa un correo electr\xF3nico y una contrase\xF1a v\xE1lidos.");
  }
  const session = await useAdminSession(event);
  const res = await wellezyLogin(event, email, password);
  switch (res.status) {
    case 200:
      break;
    case 401:
      throw authError(401, "Correo electr\xF3nico o contrase\xF1a incorrectos.");
    case 403:
      throw authError(403, MSG_FORBIDDEN);
    case 422:
      throw authError(422, "Ingresa un correo electr\xF3nico y una contrase\xF1a v\xE1lidos.");
    case 429:
      throw authError(429, "Demasiados intentos. Espera unos minutos e intenta nuevamente.");
    default:
      throw authError(503, MSG_UNAVAILABLE);
  }
  const { token, user } = res.data;
  if (!isAuthorizedUser(event, user)) {
    await wellezyLogout(event, token);
    await session.clear();
    throw authError(403, MSG_FORBIDDEN);
  }
  const publicUser = toPublicUser(user);
  await session.update({ token, user: publicUser });
  return { user: publicUser };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
