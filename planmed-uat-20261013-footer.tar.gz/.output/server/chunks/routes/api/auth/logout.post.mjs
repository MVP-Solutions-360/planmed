import { c as defineEventHandler, e as setHeader } from '../../../_/nitro.mjs';
import { a as assertSameOrigin } from '../../../_/origin.mjs';
import { u as useAdminSession } from '../../../_/auth.mjs';
import { b as wellezyLogout } from '../../../_/wellezy.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';

const logout_post = defineEventHandler(async (event) => {
  assertSameOrigin(event);
  setHeader(event, "Cache-Control", "no-store");
  const session = await useAdminSession(event);
  const token = session.data.token;
  try {
    if (token) await wellezyLogout(event, token);
  } finally {
    await session.clear();
  }
  return { ok: true };
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
