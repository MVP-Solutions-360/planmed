import { c as defineEventHandler, e as setHeader } from '../../../_/nitro.mjs';
import { u as useAdminSession, a as authError, i as isAuthorizedUser, t as toPublicUser, b as MSG_FORBIDDEN, M as MSG_UNAVAILABLE } from '../../../_/auth.mjs';
import { c as wellezyMe, b as wellezyLogout } from '../../../_/wellezy.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';

const me_get = defineEventHandler(async (event) => {
  setHeader(event, "Cache-Control", "no-store");
  const session = await useAdminSession(event);
  const token = session.data.token;
  if (!token) throw authError(401, "No autenticado");
  const res = await wellezyMe(event, token);
  if (res.status === 401) {
    await session.clear();
    throw authError(401, "No autenticado");
  }
  if (res.status === 403) {
    await session.clear();
    throw authError(403, MSG_FORBIDDEN);
  }
  if (res.status !== 200) {
    throw authError(503, MSG_UNAVAILABLE);
  }
  const user = res.data.user;
  if (!isAuthorizedUser(event, user)) {
    await wellezyLogout(event, token);
    await session.clear();
    throw authError(403, MSG_FORBIDDEN);
  }
  const publicUser = toPublicUser(user);
  await session.update({ token, user: publicUser });
  return { user: publicUser };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
