import { c as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { h as hubPrp, a as pickPrpBody } from '../../../_/prp.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/origin.mjs';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event).catch(() => null);
  return hubPrp(event, "POST", "", { body: pickPrpBody(body) });
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
