import { c as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { h as hubProcedures, a as pickProcedureBody, b as applyProcedureMedia, f as fromCms } from '../../../_/procedures.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/recommendations.mjs';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/news.mjs';
import '../../../_/origin.mjs';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event).catch(() => null);
  const res = await hubProcedures(event, "POST", "", { body: pickProcedureBody(body) });
  const last = await applyProcedureMedia(event, Number(res.data.id), body, res.data);
  return fromCms(last);
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
