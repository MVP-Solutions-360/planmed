import { c as defineEventHandler, r as readBody } from '../../../../_/nitro.mjs';
import { p as parseNewsId, h as hubNews, a as pickNewsBody, b as hubNewsCover, f as fromCmsPost } from '../../../../_/news.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/auth.mjs';
import '../../../../_/wellezy.mjs';
import '../../../../_/origin.mjs';

const _id__put = defineEventHandler(async (event) => {
  const id = parseNewsId(event);
  const body = await readBody(event).catch(() => null);
  let res = await hubNews(event, "PUT", `/${id}`, { body: pickNewsBody(body) });
  if (typeof (body == null ? void 0 : body.coverImage) === "string" && body.coverImage.startsWith("data:")) {
    res = await hubNewsCover(event, id, body.coverImage);
  }
  return fromCmsPost(res.data);
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
