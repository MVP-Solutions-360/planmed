import { c as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { h as hubNews, a as pickNewsBody, b as hubNewsCover, f as fromCmsPost } from '../../../_/news.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/origin.mjs';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event).catch(() => null);
  let res = await hubNews(event, "POST", "", { body: pickNewsBody(body) });
  if (typeof (body == null ? void 0 : body.coverImage) === "string" && body.coverImage.startsWith("data:")) {
    res = await hubNewsCover(event, Number(res.data.id), body.coverImage);
  }
  return fromCmsPost(res.data);
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
