import { c as defineEventHandler, g as getQuery } from '../../../_/nitro.mjs';
import { c as hubProceduresAll, d as pickProcedureQuery, f as fromCms } from '../../../_/procedures.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/recommendations.mjs';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/news.mjs';
import '../../../_/origin.mjs';

const index_get = defineEventHandler(async (event) => {
  const rows = await hubProceduresAll(event, pickProcedureQuery(getQuery(event)));
  return { data: rows.map(fromCms) };
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
