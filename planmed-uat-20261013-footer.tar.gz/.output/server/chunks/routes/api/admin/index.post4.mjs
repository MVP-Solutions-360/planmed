import { c as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { a as hubRecommendations, d as pickCreateBody, f as fromCmsPage } from '../../../_/recommendations.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/news.mjs';
import '../../../_/origin.mjs';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event).catch(() => null);
  const res = await hubRecommendations(event, "POST", "", { body: pickCreateBody(body) });
  return fromCmsPage(res.data);
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
