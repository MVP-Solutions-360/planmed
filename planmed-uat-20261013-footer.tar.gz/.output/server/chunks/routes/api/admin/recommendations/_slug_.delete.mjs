import { c as defineEventHandler } from '../../../../_/nitro.mjs';
import { h as hubPageBySlug, p as parsePageSlug, a as hubRecommendations } from '../../../../_/recommendations.mjs';
import { a as authError } from '../../../../_/auth.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/news.mjs';
import '../../../../_/origin.mjs';
import '../../../../_/wellezy.mjs';

const _slug__delete = defineEventHandler(async (event) => {
  const row = await hubPageBySlug(event, parsePageSlug(event));
  if (row.is_custom === false) throw authError(403, "Las p\xE1ginas base no se pueden eliminar; puedes ocultarlas.");
  await hubRecommendations(event, "DELETE", `/${Number(row.id)}`);
  return { ok: true };
});

export { _slug__delete as default };
//# sourceMappingURL=_slug_.delete.mjs.map
