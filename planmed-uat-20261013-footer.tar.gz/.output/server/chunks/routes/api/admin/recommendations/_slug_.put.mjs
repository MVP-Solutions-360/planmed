import { c as defineEventHandler, r as readBody } from '../../../../_/nitro.mjs';
import { p as parsePageSlug, h as hubPageBySlug, b as pickPageBody, a as hubRecommendations, c as hubPageImage, f as fromCmsPage } from '../../../../_/recommendations.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/auth.mjs';
import '../../../../_/wellezy.mjs';
import '../../../../_/news.mjs';
import '../../../../_/origin.mjs';

const _slug__put = defineEventHandler(async (event) => {
  const slug = parsePageSlug(event);
  const body = await readBody(event).catch(() => null);
  const row = await hubPageBySlug(event, slug);
  const id = Number(row.id);
  const fields = pickPageBody(body);
  let last = Object.keys(fields).length ? (await hubRecommendations(event, "PUT", `/${id}`, { body: fields })).data : row;
  if (typeof (body == null ? void 0 : body.image) === "string") {
    if (body.image.startsWith("data:")) last = (await hubPageImage(event, id, body.image)).data;
    else if (body.image === "" && last.image_url) last = (await hubRecommendations(event, "DELETE", `/${id}/image`)).data;
  }
  return fromCmsPage(last);
});

export { _slug__put as default };
//# sourceMappingURL=_slug_.put.mjs.map
