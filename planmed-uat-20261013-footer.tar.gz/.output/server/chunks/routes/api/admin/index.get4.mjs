import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { a as hubRecommendations, f as fromCmsPage } from '../../../_/recommendations.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/news.mjs';
import '../../../_/origin.mjs';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const res = await hubRecommendations(event, "GET", "");
  return { data: ((_a = res == null ? void 0 : res.data) != null ? _a : []).map(fromCmsPage) };
});

export { index_get as default };
//# sourceMappingURL=index.get4.mjs.map
