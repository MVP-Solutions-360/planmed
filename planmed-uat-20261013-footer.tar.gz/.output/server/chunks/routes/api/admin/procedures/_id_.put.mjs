import { c as defineEventHandler, r as readBody } from '../../../../_/nitro.mjs';
import { p as parseProcedureId, a as pickProcedureBody, h as hubProcedures, b as applyProcedureMedia, f as fromCms } from '../../../../_/procedures.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/recommendations.mjs';
import '../../../../_/auth.mjs';
import '../../../../_/wellezy.mjs';
import '../../../../_/news.mjs';
import '../../../../_/origin.mjs';

const _id__put = defineEventHandler(async (event) => {
  const id = parseProcedureId(event);
  const body = await readBody(event).catch(() => null);
  const fields = pickProcedureBody(body);
  const res = Object.keys(fields).length ? await hubProcedures(event, "PUT", `/${id}`, { body: fields }) : await hubProcedures(event, "GET", `/${id}`);
  const last = await applyProcedureMedia(event, id, body, res.data);
  return fromCms(last);
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
