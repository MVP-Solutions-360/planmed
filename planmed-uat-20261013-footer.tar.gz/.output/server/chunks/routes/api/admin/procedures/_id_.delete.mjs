import { c as defineEventHandler } from '../../../../_/nitro.mjs';
import { h as hubProcedures, p as parseProcedureId, f as fromCms } from '../../../../_/procedures.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/recommendations.mjs';
import '../../../../_/auth.mjs';
import '../../../../_/wellezy.mjs';
import '../../../../_/news.mjs';
import '../../../../_/origin.mjs';

const _id__delete = defineEventHandler(async (event) => {
  const res = await hubProcedures(event, "DELETE", `/${parseProcedureId(event)}`);
  return fromCms(res.data);
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
