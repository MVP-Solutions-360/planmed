import { c as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { d as adminSession } from '../../../_/news.mjs';
import { p as parseContentBody, a as applyContent, w as withPartialState, r as readCmsContent } from '../../../_/patients.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/origin.mjs';

const patientSection_put = defineEventHandler(async (event) => {
  await adminSession(event);
  const next = parseContentBody(await readBody(event).catch(() => null));
  const progress = { writes: 0 };
  try {
    await applyContent(event, next, progress);
  } catch (error) {
    throw await withPartialState(event, error, progress);
  }
  return (await readCmsContent(event)).content;
});

export { patientSection_put as default };
//# sourceMappingURL=patient-section.put.mjs.map
