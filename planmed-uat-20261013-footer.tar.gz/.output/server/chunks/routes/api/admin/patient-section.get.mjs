import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { r as readCmsContent } from '../../../_/patients.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/news.mjs';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/origin.mjs';

const patientSection_get = defineEventHandler(async (event) => {
  return (await readCmsContent(event)).content;
});

export { patientSection_get as default };
//# sourceMappingURL=patient-section.get.mjs.map
