import { c as defineEventHandler, g as getQuery } from '../../../_/nitro.mjs';
import { h as hubNews, c as pickNewsQuery, f as fromCmsPost } from '../../../_/news.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/origin.mjs';

const index_get = defineEventHandler(async (event) => {
  var _a, _b;
  const res = await hubNews(event, "GET", "", { query: pickNewsQuery(getQuery(event)) });
  return { data: ((_a = res == null ? void 0 : res.data) != null ? _a : []).map(fromCmsPost), meta: (_b = res == null ? void 0 : res.meta) != null ? _b : null };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
