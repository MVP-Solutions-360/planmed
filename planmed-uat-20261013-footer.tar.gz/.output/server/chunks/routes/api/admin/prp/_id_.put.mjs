import { c as defineEventHandler, r as readBody } from '../../../../_/nitro.mjs';
import { p as parsePrpId, h as hubPrp, a as pickPrpBody } from '../../../../_/prp.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/auth.mjs';
import '../../../../_/wellezy.mjs';
import '../../../../_/origin.mjs';

const _id__put = defineEventHandler(async (event) => {
  const id = parsePrpId(event);
  const body = await readBody(event).catch(() => null);
  return hubPrp(event, "PUT", `/${id}`, { body: pickPrpBody(body) });
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
