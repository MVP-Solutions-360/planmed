import { c as defineEventHandler } from '../../../../_/nitro.mjs';
import { h as hubPrp, p as parsePrpId } from '../../../../_/prp.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/auth.mjs';
import '../../../../_/wellezy.mjs';
import '../../../../_/origin.mjs';

const _id__delete = defineEventHandler((event) => hubPrp(event, "DELETE", `/${parsePrpId(event)}`));

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
