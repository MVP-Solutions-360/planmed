import { c as defineEventHandler, g as getQuery } from '../../../_/nitro.mjs';
import { h as hubPrp, b as pickPrpQuery } from '../../../_/prp.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/wellezy.mjs';
import '../../../_/origin.mjs';

const index_get = defineEventHandler((event) => hubPrp(event, "GET", "", { query: pickPrpQuery(getQuery(event)) }));

export { index_get as default };
//# sourceMappingURL=index.get3.mjs.map
