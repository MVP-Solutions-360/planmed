import { c as defineEventHandler, e as setHeader } from '../../../../_/nitro.mjs';
import { r as requireAreaLeader } from '../../../../_/auth.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/wellezy.mjs';

const access_get = defineEventHandler(async (event) => {
  setHeader(event, "Cache-Control", "no-store");
  await requireAreaLeader(event);
  return { ok: true };
});

export { access_get as default };
//# sourceMappingURL=access.get.mjs.map
