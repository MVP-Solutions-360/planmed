import { c as defineEventHandler, e as setHeader } from '../../../_/nitro.mjs';
import { d as wellezyPublicGet } from '../../../_/wellezy.mjs';
import { a as assertHubOk } from '../../../_/publicErrors.mjs';
import { f as fromPublicSection } from '../../../_/patients.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/news.mjs';
import '../../../_/auth.mjs';
import '../../../_/origin.mjs';

const patientSection_get = defineEventHandler(async (event) => {
  var _a;
  setHeader(event, "Cache-Control", "no-store");
  const res = await wellezyPublicGet(event, "/v1/web/patient-section");
  assertHubOk("patients", res, !!((_a = res.data) == null ? void 0 : _a.data) && typeof res.data.data === "object", "No fue posible cargar el contenido. Intenta nuevamente.");
  return fromPublicSection(res.data.data);
});

export { patientSection_get as default };
//# sourceMappingURL=patient-section.get.mjs.map
