import { c as defineEventHandler, e as setHeader, h as getRouterParam, f as createError } from '../../../../_/nitro.mjs';
import { d as wellezyPublicGet } from '../../../../_/wellezy.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';

const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const _slug__get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  setHeader(event, "Cache-Control", "no-store");
  const slug = String((_a = getRouterParam(event, "slug")) != null ? _a : "");
  if (!slug || slug.length > 255 || !SLUG_RE.test(slug)) {
    throw createError({ statusCode: 404, message: "No encontrado" });
  }
  const res = await wellezyPublicGet(event, `/v1/web/prp/${slug}`);
  if (res.status === 404) {
    if (String((_c = (_b = res.data) == null ? void 0 : _b.message) != null ? _c : "").includes("Tenant")) {
      console.error("[prp] Hub no resolvi\xF3 el tenant (revisa NUXT_WELLEZY_LINE_SLUG).");
    }
    throw createError({ statusCode: 404, message: "No encontrado" });
  }
  const prp = (_d = res.data) == null ? void 0 : _d.data;
  if (res.status !== 200 || !prp || typeof prp.name !== "string" || typeof prp.slug !== "string" || typeof prp.external_code !== "string") {
    throw createError({ statusCode: 503, message: "No fue posible cargar esta p\xE1gina. Intenta nuevamente." });
  }
  return {
    name: prp.name,
    slug: prp.slug,
    title: typeof prp.title === "string" && prp.title ? prp.title : null,
    externalCode: prp.external_code
  };
});

export { _slug__get as default };
//# sourceMappingURL=_slug_.get.mjs.map
