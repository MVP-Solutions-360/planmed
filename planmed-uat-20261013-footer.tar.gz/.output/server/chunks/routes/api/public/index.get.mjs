import { c as defineEventHandler, e as setHeader } from '../../../_/nitro.mjs';
import { d as wellezyPublicGet } from '../../../_/wellezy.mjs';
import { a as assertHubOk } from '../../../_/publicErrors.mjs';
import { e as fromPublicPost } from '../../../_/news.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/auth.mjs';
import '../../../_/origin.mjs';

const index_get = defineEventHandler(async (event) => {
  var _a;
  setHeader(event, "Cache-Control", "no-store");
  const res = await wellezyPublicGet(event, "/v1/web/posts?per_page=50");
  assertHubOk("news", res, Array.isArray((_a = res.data) == null ? void 0 : _a.data), "No fue posible cargar las noticias. Intenta nuevamente.");
  return res.data.data.map(fromPublicPost);
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
