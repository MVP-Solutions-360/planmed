import { c as defineEventHandler, e as setHeader, h as getRouterParam, f as createError } from '../../../../_/nitro.mjs';
import { d as wellezyPublicGet } from '../../../../_/wellezy.mjs';
import { i as isTenantNotResolved, a as assertHubOk } from '../../../../_/publicErrors.mjs';
import { e as fromPublicPage } from '../../../../_/recommendations.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/auth.mjs';
import '../../../../_/news.mjs';
import '../../../../_/origin.mjs';

const _slug__get = defineEventHandler(async (event) => {
  var _a, _b;
  setHeader(event, "Cache-Control", "no-store");
  const slug = String((_a = getRouterParam(event, "slug")) != null ? _a : "");
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) throw createError({ statusCode: 404, message: "La p\xE1gina no existe." });
  const res = await wellezyPublicGet(event, `/v1/web/recommendation-pages/${slug}`);
  if (res.status === 404 && !isTenantNotResolved(res)) throw createError({ statusCode: 404, message: "La p\xE1gina no existe." });
  assertHubOk("recommendations", res, !!((_b = res.data) == null ? void 0 : _b.data), "No fue posible cargar la p\xE1gina. Intenta nuevamente.");
  return fromPublicPage(res.data.data);
});

export { _slug__get as default };
//# sourceMappingURL=_slug_.get.mjs.map
