import { c as defineEventHandler, e as setHeader, h as getRouterParam, f as createError } from '../../../../_/nitro.mjs';
import { d as wellezyPublicGet } from '../../../../_/wellezy.mjs';
import { i as isTenantNotResolved, a as assertHubOk } from '../../../../_/publicErrors.mjs';
import { e as fromPublicPost } from '../../../../_/news.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../../_/auth.mjs';
import '../../../../_/origin.mjs';

const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const _slug__get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  setHeader(event, "Cache-Control", "no-store");
  const slug = String((_a = getRouterParam(event, "slug")) != null ? _a : "");
  if (!slug || slug.length > 255 || !SLUG_RE.test(slug)) {
    throw createError({ statusCode: 404, message: "No encontrado" });
  }
  const res = await wellezyPublicGet(event, `/v1/web/posts/${slug}`);
  if (res.status === 404 && !isTenantNotResolved(res)) throw createError({ statusCode: 404, message: "No encontrado" });
  assertHubOk("news", res, !!((_c = (_b = res.data) == null ? void 0 : _b.data) == null ? void 0 : _c.slug), "No fue posible cargar esta noticia. Intenta nuevamente.");
  return fromPublicPost(res.data.data);
});

export { _slug__get as default };
//# sourceMappingURL=_slug_.get.mjs.map
