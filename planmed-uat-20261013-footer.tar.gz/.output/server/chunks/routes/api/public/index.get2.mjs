import { c as defineEventHandler, e as setHeader } from '../../../_/nitro.mjs';
import { d as wellezyPublicGet } from '../../../_/wellezy.mjs';
import { a as assertHubOk } from '../../../_/publicErrors.mjs';
import { g as fromPublicListItem } from '../../../_/procedures.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import '../../../_/recommendations.mjs';
import '../../../_/auth.mjs';
import '../../../_/news.mjs';
import '../../../_/origin.mjs';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  setHeader(event, "Cache-Control", "no-store");
  const rows = [];
  for (let page = 1; page <= 20; page++) {
    const res = await wellezyPublicGet(event, `/v1/web/cirugias?page=${page}`);
    assertHubOk("procedures", res, Array.isArray((_a = res.data) == null ? void 0 : _a.data), "No fue posible cargar los procedimientos. Intenta nuevamente.");
    rows.push(...res.data.data);
    if (page >= Number((_c = (_b = res.data.meta) == null ? void 0 : _b.last_page) != null ? _c : 1)) break;
  }
  return rows.map(fromPublicListItem);
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
