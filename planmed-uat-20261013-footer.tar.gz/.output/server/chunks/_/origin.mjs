import { j as getRequestHeader } from './nitro.mjs';
import { a as authError } from './auth.mjs';

function assertSameOrigin(event) {
  const method = event.method;
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") return;
  const host = getRequestHeader(event, "x-forwarded-host") || getRequestHeader(event, "host");
  const denied = () => authError(403, "Origen no permitido");
  const hostOf = (url) => {
    try {
      return new URL(url).host;
    } catch {
      return "";
    }
  };
  const origin = getRequestHeader(event, "origin");
  if (origin) {
    if (!host || hostOf(origin) !== host) throw denied();
    return;
  }
  const site = getRequestHeader(event, "sec-fetch-site");
  if (site) {
    if (site !== "same-origin") throw denied();
    return;
  }
  const referer = getRequestHeader(event, "referer");
  if (referer) {
    if (!host || hostOf(referer) !== host) throw denied();
    return;
  }
  throw denied();
}

export { assertSameOrigin as a };
//# sourceMappingURL=origin.mjs.map
