import { f as createError } from './nitro.mjs';

const isTenantNotResolved = (res) => {
  var _a, _b;
  return res.status === 404 && String((_b = (_a = res.data) == null ? void 0 : _a.message) != null ? _b : "").includes("Tenant");
};
function classifyHubFailure(res, bodyIsValid) {
  if (isTenantNotResolved(res)) return "tenant";
  if (res.status === 200) return bodyIsValid ? null : "invalid_response";
  if (res.status === 401 || res.status === 403) return "rejected";
  return "hub_unavailable";
}
function assertHubOk(scope, res, bodyIsValid, message) {
  const reason = classifyHubFailure(res, bodyIsValid);
  if (!reason) return;
  if (reason === "tenant") console.error(`[${scope}] Hub no resolvi\xF3 el tenant (revisa NUXT_WELLEZY_LINE_SLUG).`);
  else if (reason !== "hub_unavailable") console.error(`[${scope}] Respuesta del Hub no utilizable: ${reason} (estado ${res.status}).`);
  throw createError({ statusCode: 503, message, data: { reason } });
}

export { assertHubOk as a, isTenantNotResolved as i };
//# sourceMappingURL=publicErrors.mjs.map
