import { r as recommendationHtml } from './recommendations.mjs';
import { h as getRouterParam, f as createError } from './nitro.mjs';
import { a as authError } from './auth.mjs';
import { d as adminSession, t as translate, g as dataUrlToBlob } from './news.mjs';
import { w as wellezyRequest, e as wellezyUpload } from './wellezy.mjs';

const MSG_NOT_FOUND = "El procedimiento no existe.";
const str = (v) => typeof v === "string" ? v : "";
const orUndef = (v) => typeof v === "string" && v !== "" ? v : void 0;
const numOrNull = (v) => v === null || v === void 0 || v === "" || !Number.isFinite(Number(v)) ? null : Number(v);
const orNull = (v) => typeof v === "string" && v.trim() !== "" ? v.trim() : null;
const SOURCES = ["pagina", "pagina_oculta", "historico", "ninguna"];
function fromRecommendationSources(raw) {
  if (!raw || typeof raw !== "object") return void 0;
  const out = {};
  for (const kind of ["cuidados", "revision"]) {
    const s = raw[kind];
    if (s && SOURCES.includes(s.fuente)) out[kind] = { fuente: s.fuente, paginaSlug: s.fuente === "pagina" ? orNull(s.pagina_slug) : null };
  }
  return Object.keys(out).length ? out : void 0;
}
function fromPublicListItem(item) {
  return {
    id: String(item.slug),
    slug: String(item.slug),
    name: str(item.nombre),
    category: str(item.categoria_slug),
    shortDescription: str(item.descripcion_corta),
    whatIsIt: "",
    image: str(item.imagen_destacada),
    galeria: [],
    destacado: item.destacado === true,
    tiene_recomendaciones_post: item.tiene_recomendaciones_post === true,
    tiene_recomendaciones_revision: item.tiene_recomendaciones_revision === true,
    recomendaciones: fromRecommendationSources(item.recomendaciones),
    ficha_tecnica: {},
    perfil_paciente: {},
    seo: {}
  };
}
function fromPublicDetail(d) {
  var _a, _b, _c, _d, _e, _f, _g;
  const datos = (_a = d.datos_paciente) != null ? _a : {};
  return {
    id: String(d.slug),
    slug: String(d.slug),
    name: str(d.nombre),
    category: str((_b = d.categoria) == null ? void 0 : _b.slug),
    shortDescription: str(d.descripcion_corta),
    whatIsIt: str(d.procedimiento),
    image: str(d.imagen_destacada),
    galeria: Array.isArray(d.galeria) ? d.galeria.filter((u) => typeof u === "string") : [],
    destacado: d.destacado === true,
    // Hub devuelve HTML (string) o, en datos históricos, una lista: se muestra como lista sin modificar el dato almacenado.
    recomendaciones_post: recommendationHtml(d.recomendaciones_post),
    recomendaciones_revision: recommendationHtml(d.recomendaciones_revision),
    recomendaciones: fromRecommendationSources(d.recomendaciones),
    ficha_tecnica: {
      tipo_anestesia: orUndef((_c = d.ficha_tecnica) == null ? void 0 : _c.tipo_anestesia),
      tiempo_quirurgico: orUndef((_d = d.ficha_tecnica) == null ? void 0 : _d.tiempo_quirurgico),
      tiempo_recuperacion: orUndef((_e = d.ficha_tecnica) == null ? void 0 : _e.tiempo_recuperacion),
      cicatrizacion_minima: datos.cicatrizacion_minima === true ? true : void 0
    },
    perfil_paciente: {
      edad_minima: numOrNull(datos.edad_minima),
      edad_maxima: numOrNull(datos.edad_maxima),
      imc_maximo: numOrNull(datos.imc_maximo),
      condiciones_medicas_compatibles: orUndef(d.perfil_paciente)
    },
    seo: { meta_title: orUndef((_f = d.seo) == null ? void 0 : _f.meta_title), meta_description: orUndef((_g = d.seo) == null ? void 0 : _g.meta_description) }
  };
}
function fromCms(d) {
  var _a, _b, _c;
  const gallery = Array.isArray(d.galeria) ? d.galeria.filter((g) => g && Number.isSafeInteger(Number(g.id)) && typeof g.url === "string").map((g) => ({ id: Number(g.id), url: g.url })) : [];
  return {
    id: String(d.id),
    slug: String(d.slug),
    name: str(d.nombre),
    category: str(d.categoria_slug),
    shortDescription: str(d.descripcion_corta),
    whatIsIt: str(d.procedimiento),
    image: str(d.imagen_destacada),
    galeria: gallery.map((g) => g.url),
    galeriaAssets: gallery,
    destacado: d.destacado === true,
    activo: d.activo === true,
    recomendaciones_post: recommendationHtml(d.recomendaciones_post),
    recomendaciones_revision: recommendationHtml(d.recomendaciones_revision),
    isMaster: d.es_maestro === true,
    editable: d.editable !== false,
    ficha_tecnica: {
      tipo_anestesia: orUndef((_a = d.ficha_tecnica) == null ? void 0 : _a.tipo_anestesia),
      tiempo_quirurgico: orUndef((_b = d.ficha_tecnica) == null ? void 0 : _b.tiempo_quirurgico),
      tiempo_recuperacion: orUndef((_c = d.ficha_tecnica) == null ? void 0 : _c.tiempo_recuperacion),
      cicatrizacion_minima: d.cicatrizacion_minima === true
    },
    perfil_paciente: {
      edad_minima: numOrNull(d.edad_minima),
      edad_maxima: numOrNull(d.edad_maxima),
      imc_maximo: numOrNull(d.imc_maximo),
      condiciones_medicas_compatibles: orUndef(d.perfil_paciente)
    },
    seo: { meta_title: orUndef(d.meta_title), meta_description: orUndef(d.meta_description) }
  };
}
function pickProcedureBody(body) {
  var _a, _b, _c, _d;
  const out = {};
  if (!body || typeof body !== "object") return out;
  if ("name" in body) out.nombre = body.name;
  if ("slug" in body && orNull(body.slug)) out.slug = orNull(body.slug);
  if ("category" in body) out.categoria_slug = orNull(body.category);
  if ("shortDescription" in body) out.descripcion_corta = orNull(body.shortDescription);
  if ("whatIsIt" in body) out.procedimiento = (_a = body.whatIsIt) != null ? _a : "";
  const ficha = body.ficha_tecnica;
  if (ficha && typeof ficha === "object") {
    out.ficha_tecnica = {
      tipo_anestesia: orNull(ficha.tipo_anestesia),
      tiempo_quirurgico: orNull(ficha.tiempo_quirurgico),
      tiempo_recuperacion: orNull(ficha.tiempo_recuperacion)
    };
    if ("cicatrizacion_minima" in ficha) out.cicatrizacion_minima = ficha.cicatrizacion_minima === true;
  }
  const perfil = body.perfil_paciente;
  if (perfil && typeof perfil === "object") {
    if ("edad_minima" in perfil) out.edad_minima = numOrNull(perfil.edad_minima);
    if ("edad_maxima" in perfil) out.edad_maxima = numOrNull(perfil.edad_maxima);
    if ("imc_maximo" in perfil) out.imc_maximo = numOrNull(perfil.imc_maximo);
    if ("condiciones_medicas_compatibles" in perfil) out.perfil_paciente = (_b = perfil.condiciones_medicas_compatibles) != null ? _b : "";
  }
  if (body.seo && typeof body.seo === "object") {
    out.meta_title = orNull(body.seo.meta_title);
    out.meta_description = orNull(body.seo.meta_description);
  }
  if ("recomendaciones_post" in body) out.recomendaciones_post = (_c = body.recomendaciones_post) != null ? _c : "";
  if ("recomendaciones_revision" in body) out.recomendaciones_revision = (_d = body.recomendaciones_revision) != null ? _d : "";
  if ("activo" in body) out.activo = body.activo === true;
  if ("destacado" in body) out.destacado = body.destacado === true;
  return out;
}
function pickProcedureQuery(query) {
  const out = {};
  for (const key of ["search", "activo", "tipo"]) {
    if (query[key] !== void 0 && query[key] !== "") out[key] = query[key];
  }
  return out;
}
function parseProcedureId(event) {
  const id = Number(getRouterParam(event, "id"));
  if (!Number.isSafeInteger(id) || id <= 0) throw authError(404, MSG_NOT_FOUND);
  return id;
}
async function hubProcedures(event, method, path, options = {}) {
  const { session, token } = await adminSession(event);
  const res = await wellezyRequest(event, token, method, `/cms/procedures${path}`, options);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data, session, MSG_NOT_FOUND);
  return res.data;
}
async function hubProceduresAll(event, query) {
  var _a, _b;
  const rows = [];
  for (let page = 1; page <= 20; page++) {
    const res = await hubProcedures(event, "GET", "", { query: { ...query, per_page: 100, page } });
    rows.push(...(_a = res == null ? void 0 : res.data) != null ? _a : []);
    if (!(res == null ? void 0 : res.meta) || page >= Number((_b = res.meta.last_page) != null ? _b : 1)) break;
  }
  return rows;
}
async function hubProcedureUpload(event, path, form) {
  const { session, token } = await adminSession(event);
  const res = await wellezyUpload(event, token, `/cms/procedures${path}`, form);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data, session, MSG_NOT_FOUND);
  return res.data;
}
function extension(blob) {
  return blob.type === "image/png" ? "png" : blob.type === "image/webp" ? "webp" : "jpg";
}
async function applyProcedureMedia(event, id, body, current) {
  let last = current;
  if (typeof (body == null ? void 0 : body.image) === "string" && body.image.startsWith("data:")) {
    const blob = dataUrlToBlob(body.image);
    if (!blob) throw createError({ statusCode: 422, message: "La imagen debe ser JPG, PNG o WebP de m\xE1ximo 5 MB." });
    const form = new FormData();
    form.append("image", blob, `procedimiento.${extension(blob)}`);
    last = (await hubProcedureUpload(event, `/${id}/image`, form)).data;
  }
  const uploads = Array.isArray(body == null ? void 0 : body.galleryUploads) ? body.galleryUploads.filter((u) => typeof u === "string") : [];
  if (uploads.length) {
    const form = new FormData();
    for (const [i, dataUrl] of uploads.slice(0, 10).entries()) {
      const blob = dataUrlToBlob(dataUrl);
      if (!blob) throw createError({ statusCode: 422, message: "Las im\xE1genes de la galer\xEDa deben ser JPG, PNG o WebP de m\xE1ximo 5 MB." });
      form.append("images[]", blob, `galeria-${i + 1}.${extension(blob)}`);
    }
    last = (await hubProcedureUpload(event, `/${id}/gallery`, form)).data;
  }
  const removals = Array.isArray(body == null ? void 0 : body.galleryRemovals) ? body.galleryRemovals.map(Number).filter((n) => Number.isSafeInteger(n) && n > 0) : [];
  for (const assetId of removals) {
    last = (await hubProcedures(event, "DELETE", `/${id}/gallery/${assetId}`)).data;
  }
  return last;
}

export { pickProcedureBody as a, applyProcedureMedia as b, hubProceduresAll as c, pickProcedureQuery as d, fromPublicDetail as e, fromCms as f, fromPublicListItem as g, hubProcedures as h, parseProcedureId as p };
//# sourceMappingURL=procedures.mjs.map
