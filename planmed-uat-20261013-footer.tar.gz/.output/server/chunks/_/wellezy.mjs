import { u as useRuntimeConfig } from './nitro.mjs';

const TIMEOUT_MS = 1e4;
function baseUrl(event) {
  const base = String(useRuntimeConfig(event).wellezyApiBaseUrl || "").replace(/\/+$/, "");
  if (!base) console.error("[auth] NUXT_WELLEZY_API_BASE_URL no est\xE1 configurada.");
  return base;
}
async function call(event, path, options) {
  const base = baseUrl(event);
  if (!base) return { status: 0 };
  const headers = { Accept: "application/json", ...options.headers };
  if (options.token) headers.Authorization = `Bearer ${options.token}`;
  try {
    const res = await $fetch.raw(`${base}${path}`, {
      method: options.method,
      body: options.body,
      query: options.query,
      headers,
      timeout: TIMEOUT_MS,
      retry: 0,
      ignoreResponseError: true
    });
    return { status: res.status, data: res._data };
  } catch {
    return { status: 0 };
  }
}
function isWellezyUser(value) {
  return !!value && Number.isSafeInteger(Number(value.id)) && typeof value.name === "string" && typeof value.email === "string" && (value.role === null || value.role && Number.isSafeInteger(Number(value.role.id)) && typeof value.role.name === "string");
}
async function wellezyLogin(event, email, password) {
  var _a;
  const config = useRuntimeConfig(event);
  const res = await call(event, "/auth/login", {
    method: "POST",
    body: { email, password, company: config.wellezyCompanySlug, line: config.wellezyLineSlug }
  });
  if (res.status !== 200) return { status: res.status };
  if (typeof ((_a = res.data) == null ? void 0 : _a.token) !== "string" || !res.data.token || !isWellezyUser(res.data.user)) return { status: 0 };
  return { status: 200, data: { token: res.data.token, user: res.data.user } };
}
async function wellezyMe(event, token) {
  var _a;
  const res = await call(event, "/auth/me", { method: "GET", token });
  if (res.status !== 200) return { status: res.status };
  if (!isWellezyUser((_a = res.data) == null ? void 0 : _a.user)) return { status: 0 };
  return { status: 200, data: { user: res.data.user } };
}
async function wellezyLogout(event, token) {
  return (await call(event, "/auth/logout", { method: "POST", token })).status;
}
function wellezyRequest(event, token, method, path, options = {}) {
  return call(event, path, { method, token, ...options });
}
async function wellezyUpload(event, token, path, form) {
  const base = baseUrl(event);
  if (!base) return { status: 0 };
  try {
    const res = await $fetch.raw(`${base}${path}`, {
      method: "POST",
      body: form,
      headers: { Accept: "application/json", Authorization: `Bearer ${token}` },
      timeout: 3e4,
      retry: 0,
      ignoreResponseError: true
    });
    return { status: res.status, data: res._data };
  } catch {
    return { status: 0 };
  }
}
function wellezyPublicGet(event, path) {
  const lineSlug = String(useRuntimeConfig(event).wellezyLineSlug || "");
  if (!lineSlug) console.error("[prp] NUXT_WELLEZY_LINE_SLUG no est\xE1 configurada.");
  return call(event, path, { method: "GET", headers: { "X-Tenant-Linea": lineSlug } });
}

export { wellezyLogin as a, wellezyLogout as b, wellezyMe as c, wellezyPublicGet as d, wellezyUpload as e, wellezyRequest as w };
//# sourceMappingURL=wellezy.mjs.map
