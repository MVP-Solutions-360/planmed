import { f as createError } from './nitro.mjs';
import { d as adminSession, t as translate, g as dataUrlToBlob } from './news.mjs';
import { w as wellezyRequest, e as wellezyUpload } from './wellezy.mjs';

const MSG_NOT_FOUND = "El contenido no existe.";
const MAX_ITEMS = 100;
const YOUTUBE_RE = /^https?:\/\/(www\.|m\.|music\.)?(youtube\.com|youtube-nocookie\.com|youtu\.be)\//i;
const INSTAGRAM_RE = /^https?:\/\/(www\.)?instagram\.com\/(p|reel|reels|tv)\//i;
const str = (v) => typeof v === "string" ? v : "";
const orNull = (v) => typeof v === "string" && v.trim() !== "" ? v.trim() : null;
const hubId = (v) => {
  const n = Number(v);
  return typeof v !== "object" && /^\d+$/.test(String(v)) && Number.isSafeInteger(n) && n > 0 ? n : null;
};
function fromPublicSection(d) {
  var _a, _b, _c, _d;
  const embed = (e, i) => ({ id: str(e == null ? void 0 : e.external_id) || String(i), title: str(e == null ? void 0 : e.title), url: str(e == null ? void 0 : e.url), active: true });
  return {
    visibility: { videos: ((_a = d == null ? void 0 : d.visibility) == null ? void 0 : _a.videos) !== false, beforeAfter: ((_b = d == null ? void 0 : d.visibility) == null ? void 0 : _b.before_after) !== false },
    videos: (Array.isArray(d == null ? void 0 : d.videos) ? d.videos : []).map(embed),
    instagram: (Array.isArray(d == null ? void 0 : d.instagram) ? d.instagram : []).map((e, i) => ({ ...embed(e, i), title: str(e == null ? void 0 : e.title) })),
    beforeAfter: (Array.isArray(d == null ? void 0 : d.before_after) ? d.before_after : []).map((c, i) => ({
      id: String(i),
      title: str(c == null ? void 0 : c.title),
      description: str(c == null ? void 0 : c.description),
      beforeImage: str(c == null ? void 0 : c.before_url),
      afterImage: str(c == null ? void 0 : c.after_url),
      published: true
    })),
    referral: { title: str((_c = d == null ? void 0 : d.referral) == null ? void 0 : _c.title), content: str((_d = d == null ? void 0 : d.referral) == null ? void 0 : _d.content) }
  };
}
function fromCmsPatients(settings, embeds, cases) {
  const rows = embeds.filter((e) => e && hubId(e.id) !== null);
  return {
    visibility: { videos: (settings == null ? void 0 : settings.show_videos) !== false, beforeAfter: (settings == null ? void 0 : settings.show_before_after) !== false },
    videos: rows.filter((e) => e.platform === "youtube").map((e) => ({ id: String(e.id), title: str(e.title), url: str(e.url), active: e.activo === true })),
    instagram: rows.filter((e) => e.platform === "instagram").map((e) => ({ id: String(e.id), url: str(e.url), title: str(e.title), active: e.activo === true })),
    beforeAfter: cases.filter((c) => c && hubId(c.id) !== null).map((c) => ({
      id: String(c.id),
      title: str(c.title),
      description: str(c.description),
      beforeImage: str(c.before_url),
      afterImage: str(c.after_url),
      published: c.published === true
    })),
    referral: { title: str(settings == null ? void 0 : settings.referral_title), content: str(settings == null ? void 0 : settings.referral_content) }
  };
}
function parseContentBody(body) {
  var _a, _b, _c, _d;
  const bad = () => createError({ statusCode: 422, message: "Revisa los datos ingresados." });
  if (!body || typeof body !== "object") throw bad();
  const list = (v) => Array.isArray(v) ? v : (() => {
    throw bad();
  })();
  const videos = list(body.videos), instagram = list(body.instagram), cases = list(body.beforeAfter);
  if (videos.length + instagram.length > MAX_ITEMS || cases.length > MAX_ITEMS) throw bad();
  const parsed = {
    visibility: { videos: ((_a = body.visibility) == null ? void 0 : _a.videos) !== false, beforeAfter: ((_b = body.visibility) == null ? void 0 : _b.beforeAfter) !== false },
    videos: videos.map((v) => ({ id: str(v == null ? void 0 : v.id), title: str(v == null ? void 0 : v.title).trim(), url: str(v == null ? void 0 : v.url).trim(), active: (v == null ? void 0 : v.active) !== false })),
    instagram: instagram.map((v) => ({ id: str(v == null ? void 0 : v.id), title: str(v == null ? void 0 : v.title).trim(), url: str(v == null ? void 0 : v.url).trim(), active: (v == null ? void 0 : v.active) !== false })),
    beforeAfter: cases.map((c) => ({
      id: str(c == null ? void 0 : c.id),
      title: str(c == null ? void 0 : c.title).trim(),
      description: str(c == null ? void 0 : c.description),
      beforeImage: str(c == null ? void 0 : c.beforeImage),
      afterImage: str(c == null ? void 0 : c.afterImage),
      published: (c == null ? void 0 : c.published) !== false
    })),
    referral: { title: str((_c = body.referral) == null ? void 0 : _c.title), content: str((_d = body.referral) == null ? void 0 : _d.content) }
  };
  const invalid = (message) => createError({ statusCode: 422, message, data: { message, errors: {} } });
  if (parsed.videos.some((v) => !YOUTUBE_RE.test(v.url))) throw invalid("Solo se admiten enlaces de YouTube.");
  if (parsed.instagram.some((v) => !INSTAGRAM_RE.test(v.url))) throw invalid("Usa enlaces de publicaciones o reels de Instagram.");
  if (parsed.beforeAfter.some((c) => !c.title)) throw invalid("Cada caso necesita un t\xEDtulo.");
  if (parsed.beforeAfter.some((c) => c.published && (!c.beforeImage || !c.afterImage))) throw invalid("Cada caso publicado necesita la foto del antes y la del despu\xE9s.");
  const badImage = (v) => v.startsWith("data:") && !dataUrlToBlob(v);
  if (parsed.beforeAfter.some((c) => badImage(c.beforeImage) || badImage(c.afterImage))) throw invalid("Las im\xE1genes deben ser JPG, PNG o WebP de m\xE1ximo 5 MB.");
  return parsed;
}
async function hubPatients(event, method, path, options = {}) {
  const { session, token } = await adminSession(event);
  const res = await wellezyRequest(event, token, method, `/cms/${path}`, options);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data, session, MSG_NOT_FOUND);
  return res.data;
}
async function hubCaseImages(event, id, images) {
  const form = new FormData();
  for (const side of ["before", "after"]) {
    const dataUrl = images[side];
    if (!dataUrl) continue;
    const blob = dataUrlToBlob(dataUrl);
    if (!blob) throw createError({ statusCode: 422, message: "Las im\xE1genes deben ser JPG, PNG o WebP de m\xE1ximo 5 MB." });
    form.append(side, blob, `${side}.${blob.type === "image/png" ? "png" : blob.type === "image/webp" ? "webp" : "jpg"}`);
  }
  if ([...form.keys()].length === 0) return false;
  const { session, token } = await adminSession(event);
  const res = await wellezyUpload(event, token, `/cms/before-after-cases/${id}/images`, form);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data, session, MSG_NOT_FOUND);
  return true;
}
async function readCmsContent(event) {
  var _a, _b;
  const [settings, embeds, cases] = await Promise.all([
    hubPatients(event, "GET", "patient-section"),
    hubPatients(event, "GET", "testimonial-embeds"),
    hubPatients(event, "GET", "before-after-cases")
  ]);
  const embedRows = (_a = embeds == null ? void 0 : embeds.data) != null ? _a : [];
  const caseRows = (_b = cases == null ? void 0 : cases.data) != null ? _b : [];
  return { content: fromCmsPatients(settings == null ? void 0 : settings.data, embedRows, caseRows), embeds: embedRows, cases: caseRows };
}
async function applyContent(event, next, progress = { writes: 0 }) {
  const { embeds: currentEmbeds, cases: currentCases } = await readCmsContent(event);
  const write = async (method, path, body) => {
    const res = await hubPatients(event, method, path, body ? { body } : {});
    progress.writes++;
    return res;
  };
  await write("PUT", "patient-section", {
    show_videos: next.visibility.videos,
    show_before_after: next.visibility.beforeAfter,
    referral_title: orNull(next.referral.title),
    referral_content: next.referral.content.trim() === "" ? null : next.referral.content
  });
  const items = [
    ...next.videos.map((v) => ({ ...v, platform: "youtube" })),
    ...next.instagram.map((v) => ({ ...v, platform: "instagram" }))
  ];
  const keptEmbedIds = new Set(items.map((i) => hubId(i.id)).filter((n) => n !== null));
  for (const row of currentEmbeds) {
    if (!keptEmbedIds.has(Number(row.id))) await write("DELETE", `testimonial-embeds/${Number(row.id)}`);
  }
  const embedOrder = [];
  const toCreate = [];
  for (const item of items) {
    const id = hubId(item.id);
    const row = id !== null ? currentEmbeds.find((r) => Number(r.id) === id) : null;
    if (!row) {
      toCreate.push(item);
      embedOrder.push(-toCreate.length);
      continue;
    }
    const body = {};
    if (item.url !== row.url) body.url = item.url;
    if (item.title !== str(row.title)) body.title = orNull(item.title);
    if (item.active !== (row.activo === true)) body.activo = item.active;
    if (Object.keys(body).length) await write("PUT", `testimonial-embeds/${id}`, body);
    embedOrder.push(Number(row.id));
  }
  const createdIds = [];
  for (const item of toCreate) {
    const res = await write("POST", "testimonial-embeds", { url: item.url, platform: item.platform, title: orNull(item.title), activo: item.active });
    createdIds.push(Number(res.data.id));
  }
  const finalEmbedOrder = embedOrder.map((n) => n < 0 ? createdIds[-n - 1] : n);
  if (finalEmbedOrder.length) await write("POST", "testimonial-embeds/reorder", { ids: finalEmbedOrder });
  const keptCaseIds = new Set(next.beforeAfter.map((c) => hubId(c.id)).filter((n) => n !== null));
  for (const row of currentCases) {
    if (!keptCaseIds.has(Number(row.id))) await write("DELETE", `before-after-cases/${Number(row.id)}`);
  }
  const caseOrder = [];
  for (const c of next.beforeAfter) {
    let id = hubId(c.id);
    const row = id !== null ? currentCases.find((r) => Number(r.id) === id) : null;
    if (!row) {
      const res = await write("POST", "before-after-cases", { title: c.title, description: orNull(c.description), published: c.published });
      id = Number(res.data.id);
    } else {
      const body = {};
      if (c.title !== str(row.title)) body.title = c.title;
      if (c.description !== str(row.description)) body.description = orNull(c.description);
      if (c.published !== (row.published === true)) body.published = c.published;
      if (Object.keys(body).length) await write("PUT", `before-after-cases/${id}`, body);
    }
    const uploaded = await hubCaseImages(event, id, {
      before: c.beforeImage.startsWith("data:") ? c.beforeImage : void 0,
      after: c.afterImage.startsWith("data:") ? c.afterImage : void 0
    });
    if (uploaded) progress.writes++;
    caseOrder.push(id);
  }
  if (caseOrder.length) await write("POST", "before-after-cases/reorder", { ids: caseOrder });
}
async function withPartialState(event, error, progress) {
  var _a, _b, _c, _d;
  if (progress.writes === 0 || (error == null ? void 0 : error.statusCode) === 401) return error;
  let content = null;
  try {
    content = (await readCmsContent(event)).content;
  } catch {
  }
  const reason = ((_a = error == null ? void 0 : error.data) == null ? void 0 : _a.message) || (error == null ? void 0 : error.message) || "No se pudo guardar todo.";
  const message = `${reason} Algunos cambios s\xED se guardaron antes del error${content ? ": el formulario muestra lo que qued\xF3 guardado. Revisa y vuelve a intentar." : ". Recarga la p\xE1gina para ver el estado actual."}`;
  return createError({ statusCode: (_b = error == null ? void 0 : error.statusCode) != null ? _b : 503, message, data: { message, errors: (_d = (_c = error == null ? void 0 : error.data) == null ? void 0 : _c.errors) != null ? _d : {}, partial: true, content } });
}

export { applyContent as a, fromPublicSection as f, parseContentBody as p, readCmsContent as r, withPartialState as w };
//# sourceMappingURL=patients.mjs.map
