import { e as setHeader, f as createError, h as getRouterParam } from './nitro.mjs';
import { u as useAdminSession, a as authError } from './auth.mjs';
import { a as assertSameOrigin } from './origin.mjs';
import { w as wellezyRequest } from './wellezy.mjs';

const MSG_PRP_UNAVAILABLE = "No fue posible conectar con Wellezy Hub. Intenta nuevamente.";
const MSG_PRP_FORBIDDEN = "No tienes permiso para realizar esta acci\xF3n.";
function parsePrpId(event) {
  const id = Number(getRouterParam(event, "id"));
  if (!Number.isSafeInteger(id) || id <= 0) throw authError(404, "El micrositio no existe.");
  return id;
}
function pickPrpBody(body) {
  const out = {};
  if (!body || typeof body !== "object") return out;
  for (const key of ["name", "external_code", "slug", "title", "is_active"]) {
    if (key in body) out[key] = body[key];
  }
  return out;
}
function pickPrpQuery(query) {
  const out = {};
  for (const key of ["search", "is_active", "page", "per_page"]) {
    if (query[key] !== void 0 && query[key] !== "") out[key] = query[key];
  }
  return out;
}
async function hubPrp(event, method, path, options = {}) {
  var _a, _b, _c;
  assertSameOrigin(event);
  setHeader(event, "Cache-Control", "no-store");
  const session = await useAdminSession(event);
  const token = session.data.token;
  if (!token || !session.data.user) throw authError(401, "No autenticado");
  const res = await wellezyRequest(event, token, method, `/prp-referrers${path}`, options);
  switch (res.status) {
    case 200:
    case 201:
      return res.data;
    case 401:
      await session.clear();
      throw authError(401, "No autenticado");
    case 403:
      throw authError(403, MSG_PRP_FORBIDDEN);
    case 404:
      throw authError(404, "El micrositio no existe.");
    case 422: {
      const message = typeof ((_a = res.data) == null ? void 0 : _a.message) === "string" ? res.data.message : "Revisa los datos ingresados.";
      throw createError({ statusCode: 422, message, data: { message, errors: (_c = (_b = res.data) == null ? void 0 : _b.errors) != null ? _c : {} } });
    }
    case 429:
      throw authError(429, "Demasiadas solicitudes. Espera unos segundos e intenta nuevamente.");
    default:
      throw authError(503, MSG_PRP_UNAVAILABLE);
  }
}

export { pickPrpBody as a, pickPrpQuery as b, hubPrp as h, parsePrpId as p };
//# sourceMappingURL=prp.mjs.map
