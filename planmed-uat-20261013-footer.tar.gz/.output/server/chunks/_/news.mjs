import { h as getRouterParam, f as createError, e as setHeader } from './nitro.mjs';
import { a as authError, u as useAdminSession } from './auth.mjs';
import { a as assertSameOrigin } from './origin.mjs';
import { w as wellezyRequest, e as wellezyUpload } from './wellezy.mjs';

const MSG_UNAVAILABLE = "No fue posible conectar con Wellezy Hub. Intenta nuevamente.";
const MSG_FORBIDDEN = "No tienes permiso para realizar esta acci\xF3n.";
function fromPublicPost(post) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  return {
    id: String(post.slug),
    slug: String(post.slug),
    title: String((_a = post.title) != null ? _a : ""),
    excerpt: String((_b = post.excerpt) != null ? _b : ""),
    content: String((_c = post.content) != null ? _c : ""),
    coverImage: typeof post.cover_url === "string" ? post.cover_url : "",
    publishedAt: typeof post.published_at === "string" ? post.published_at : null,
    author: typeof post.author_name === "string" ? post.author_name : void 0,
    seo: { metaTitle: (_e = (_d = post.seo) == null ? void 0 : _d.meta_title) != null ? _e : void 0, metaDescription: (_g = (_f = post.seo) == null ? void 0 : _f.meta_description) != null ? _g : void 0 },
    youtubeUrl: (_h = post.youtube_url) != null ? _h : void 0,
    instagramUrl: (_i = post.instagram_url) != null ? _i : void 0
  };
}
function fromCmsPost(post) {
  var _a, _b, _c, _d, _e, _f, _g;
  return {
    id: String(post.id),
    slug: String(post.slug),
    title: String((_a = post.title) != null ? _a : ""),
    excerpt: String((_b = post.excerpt) != null ? _b : ""),
    content: String((_c = post.content) != null ? _c : ""),
    coverImage: typeof post.cover_url === "string" ? post.cover_url : "",
    publishedAt: post.status === "published" && typeof post.published_at === "string" ? post.published_at : null,
    author: typeof post.author_name === "string" ? post.author_name : void 0,
    seo: { metaTitle: (_d = post.meta_title) != null ? _d : void 0, metaDescription: (_e = post.meta_description) != null ? _e : void 0 },
    youtubeUrl: (_f = post.youtube_url) != null ? _f : void 0,
    instagramUrl: (_g = post.instagram_url) != null ? _g : void 0
  };
}
const orNull = (v) => typeof v === "string" && v.trim() !== "" ? v.trim() : null;
function pickNewsBody(body) {
  var _a, _b;
  const out = {};
  if (!body || typeof body !== "object") return out;
  if ("title" in body) out.title = body.title;
  if ("slug" in body && orNull(body.slug)) out.slug = orNull(body.slug);
  if ("excerpt" in body) out.excerpt = (_a = body.excerpt) != null ? _a : "";
  if ("content" in body) out.content = (_b = body.content) != null ? _b : "";
  if ("publishedAt" in body) out.published_at = body.publishedAt ? body.publishedAt : null;
  if (body.seo && typeof body.seo === "object") {
    out.meta_title = orNull(body.seo.metaTitle);
    out.meta_description = orNull(body.seo.metaDescription);
  }
  if ("youtubeUrl" in body) out.youtube_url = orNull(body.youtubeUrl);
  if ("instagramUrl" in body) out.instagram_url = orNull(body.instagramUrl);
  return out;
}
function pickNewsQuery(query) {
  const out = {};
  for (const key of ["search", "status", "page", "per_page"]) {
    if (query[key] !== void 0 && query[key] !== "") out[key] = query[key];
  }
  return out;
}
function parseNewsId(event) {
  const id = Number(getRouterParam(event, "id"));
  if (!Number.isSafeInteger(id) || id <= 0) throw authError(404, "La noticia no existe.");
  return id;
}
function dataUrlToBlob(dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) return null;
  let binary;
  try {
    binary = atob(m[2]);
  } catch {
    return null;
  }
  if (binary.length === 0 || binary.length > 5 * 1024 * 1024) return null;
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: m[1] });
}
function translate(status, data, session, notFoundMessage = "La noticia no existe.") {
  var _a;
  switch (status) {
    case 200:
    case 201:
      return;
    case 401:
      throw authError(401, "No autenticado");
    case 403:
      throw authError(403, MSG_FORBIDDEN);
    case 404:
      throw authError(404, notFoundMessage);
    case 422: {
      const message = typeof (data == null ? void 0 : data.message) === "string" ? data.message : "Revisa los datos ingresados.";
      throw createError({ statusCode: 422, message, data: { message, errors: (_a = data == null ? void 0 : data.errors) != null ? _a : {} } });
    }
    case 429:
      throw authError(429, "Demasiadas solicitudes. Espera unos segundos e intenta nuevamente.");
    default:
      throw authError(503, MSG_UNAVAILABLE);
  }
}
async function adminSession(event) {
  assertSameOrigin(event);
  setHeader(event, "Cache-Control", "no-store");
  const session = await useAdminSession(event);
  const token = session.data.token;
  if (!token || !session.data.user) throw authError(401, "No autenticado");
  return { session, token };
}
async function hubNews(event, method, path, options = {}) {
  const { session, token } = await adminSession(event);
  const res = await wellezyRequest(event, token, method, `/cms/posts${path}`, options);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data);
  return res.data;
}
async function hubNewsCover(event, id, dataUrl) {
  const { session, token } = await adminSession(event);
  const blob = dataUrlToBlob(dataUrl);
  if (!blob) throw createError({ statusCode: 422, message: "La portada debe ser una imagen JPG, PNG o WebP de m\xE1ximo 5 MB." });
  const form = new FormData();
  form.append("image", blob, `portada.${blob.type === "image/png" ? "png" : blob.type === "image/webp" ? "webp" : "jpg"}`);
  const res = await wellezyUpload(event, token, `/cms/posts/${id}/cover`, form);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data);
  return res.data;
}

export { pickNewsBody as a, hubNewsCover as b, pickNewsQuery as c, adminSession as d, fromPublicPost as e, fromCmsPost as f, dataUrlToBlob as g, hubNews as h, parseNewsId as p, translate as t };
//# sourceMappingURL=news.mjs.map
