import { h as getRouterParam, f as createError } from './nitro.mjs';
import { a as authError } from './auth.mjs';
import { d as adminSession, t as translate, g as dataUrlToBlob } from './news.mjs';
import { w as wellezyRequest, e as wellezyUpload } from './wellezy.mjs';

const MSG_NOT_FOUND = "La p\xE1gina no existe.";
const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const RECOMMENDATION_GROUPS = ["general", "cuidados", "revision"];
const str = (v) => typeof v === "string" ? v : "";
const orNull = (v) => typeof v === "string" && v.trim() !== "" ? v.trim() : null;
const group = (v) => RECOMMENDATION_GROUPS.includes(v) ? v : "general";
function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function recommendationHtml(value) {
  if (typeof value === "string") return value.trim() === "" ? void 0 : value;
  if (Array.isArray(value)) {
    const items = value.filter((v) => typeof v === "string" && v.trim() !== "");
    return items.length ? `<ul>${items.map((i) => `<li>${escapeHtml(i.trim())}</li>`).join("")}</ul>` : void 0;
  }
  return void 0;
}
function fromCmsPage(d) {
  return {
    slug: str(d.slug),
    group: group(d.grupo),
    custom: d.is_custom === true,
    menuLabel: str(d.menu_label),
    title: str(d.title),
    videoUrl: str(d.video_url),
    image: str(d.image_url),
    content: str(d.content),
    published: d.published === true,
    procedureSlug: orNull(d.cirugia_slug)
  };
}
function fromPublicPage(d) {
  return {
    slug: str(d.slug),
    group: group(d.grupo),
    custom: false,
    menuLabel: str(d.menu_label),
    title: str(d.title),
    videoUrl: str(d.video_url),
    image: str(d.image_url),
    content: str(d.content),
    published: true,
    procedureSlug: orNull(d.cirugia_slug)
  };
}
function pickPageBody(body) {
  var _a;
  const out = {};
  if (!body || typeof body !== "object") return out;
  if ("title" in body) out.title = body.title;
  if ("menuLabel" in body && orNull(body.menuLabel)) out.menu_label = orNull(body.menuLabel);
  if ("videoUrl" in body) out.video_url = orNull(body.videoUrl);
  if ("content" in body) out.content = (_a = body.content) != null ? _a : "";
  if ("published" in body) out.published = body.published === true;
  return out;
}
function pickCreateBody(body) {
  const out = { title: typeof (body == null ? void 0 : body.title) === "string" ? body.title.trim() : "" };
  if (RECOMMENDATION_GROUPS.includes(body == null ? void 0 : body.group)) out.grupo = body.group;
  return out;
}
function parsePageSlug(event) {
  var _a;
  const slug = String((_a = getRouterParam(event, "slug")) != null ? _a : "");
  if (!SLUG_RE.test(slug)) throw authError(404, MSG_NOT_FOUND);
  return slug;
}
function findPageBySlug(rows, slug) {
  var _a;
  return (_a = rows.find((r) => r && r.slug === slug && Number.isSafeInteger(Number(r.id)))) != null ? _a : null;
}
async function hubRecommendations(event, method, path, options = {}) {
  const { session, token } = await adminSession(event);
  const res = await wellezyRequest(event, token, method, `/cms/recommendation-pages${path}`, options);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data, session, MSG_NOT_FOUND);
  return res.data;
}
async function hubPageBySlug(event, slug) {
  var _a;
  const list = await hubRecommendations(event, "GET", "");
  const row = findPageBySlug((_a = list == null ? void 0 : list.data) != null ? _a : [], slug);
  if (!row) throw authError(404, MSG_NOT_FOUND);
  return row;
}
async function hubPageImage(event, id, dataUrl) {
  const { session, token } = await adminSession(event);
  const blob = dataUrlToBlob(dataUrl);
  if (!blob) throw createError({ statusCode: 422, message: "La imagen debe ser JPG, PNG o WebP de m\xE1ximo 5 MB." });
  const form = new FormData();
  form.append("image", blob, `recomendacion.${blob.type === "image/png" ? "png" : blob.type === "image/webp" ? "webp" : "jpg"}`);
  const res = await wellezyUpload(event, token, `/cms/recommendation-pages/${id}/image`, form);
  if (res.status === 401) await session.clear();
  translate(res.status, res.data, session, MSG_NOT_FOUND);
  return res.data;
}

export { hubRecommendations as a, pickPageBody as b, hubPageImage as c, pickCreateBody as d, fromPublicPage as e, fromCmsPage as f, hubPageBySlug as h, parsePageSlug as p, recommendationHtml as r };
//# sourceMappingURL=recommendations.mjs.map
