import { f as createError, i as useSession, u as useRuntimeConfig } from './nitro.mjs';
import { c as wellezyMe } from './wellezy.mjs';

const SESSION_MAX_AGE = 60 * 60 * 8;
function sessionOptions(event) {
  const password = String(useRuntimeConfig(event).sessionPassword || "");
  if (password.length < 32) {
    console.error("[auth] NUXT_SESSION_PASSWORD no est\xE1 configurada (m\xEDnimo 32 caracteres).");
    throw createError({ statusCode: 503, message: "No fue posible conectar con el servicio de autenticaci\xF3n. Intenta nuevamente." });
  }
  return {
    name: "planmed-admin",
    password,
    maxAge: SESSION_MAX_AGE,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: true,
      path: "/"
    }
  };
}
function useAdminSession(event) {
  return useSession(event, sessionOptions(event));
}
function allowedRoleIds(event) {
  var _a;
  return String((_a = useRuntimeConfig(event).planmedAdminRoleIds) != null ? _a : "").split(",").map((s) => Number(s.trim())).filter((n) => Number.isSafeInteger(n) && n > 0);
}
function isAuthorizedUser(event, user) {
  return !!user.role && allowedRoleIds(event).includes(Number(user.role.id));
}
function toPublicUser(user) {
  return {
    id: Number(user.id),
    name: user.name,
    email: user.email,
    role: { id: Number(user.role.id), name: user.role.name },
    isAreaLeader: user.is_area_leader === true
  };
}
async function requireAreaLeader(event) {
  const session = await useAdminSession(event);
  const token = session.data.token;
  if (!token) throw authError(401, "No autenticado");
  const res = await wellezyMe(event, token);
  if (res.status === 401) {
    await session.clear();
    throw authError(401, "No autenticado");
  }
  if (res.status !== 200) throw authError(503, MSG_UNAVAILABLE);
  const user = res.data.user;
  if (!isAuthorizedUser(event, user) || user.is_area_leader !== true) throw authError(403, MSG_LEADER_ONLY);
  return user;
}
const MSG_UNAVAILABLE = "No fue posible conectar con el servicio de autenticaci\xF3n. Intenta nuevamente.";
const MSG_LEADER_ONLY = "Solo el l\xEDder de la l\xEDnea puede acceder a la configuraci\xF3n.";
const MSG_FORBIDDEN = "No tienes acceso al panel administrativo de Planmed.";
function authError(statusCode, message) {
  return createError({ statusCode, message, data: { message } });
}

export { MSG_UNAVAILABLE as M, authError as a, MSG_FORBIDDEN as b, isAuthorizedUser as i, requireAreaLeader as r, toPublicUser as t, useAdminSession as u };
//# sourceMappingURL=auth.mjs.map
