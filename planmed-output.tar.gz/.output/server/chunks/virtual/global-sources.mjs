const sources = [
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/admin/configuracion"
            },
            {
                "loc": "/admin/login"
            },
            {
                "loc": "/admin/micrositios"
            },
            {
                "loc": "/admin/noticias"
            },
            {
                "loc": "/admin/procedimientos"
            },
            {
                "loc": "/admin/recomendaciones"
            },
            {
                "loc": "/admin/testimonios"
            },
            {
                "loc": "/recomendaciones/cuidados"
            },
            {
                "loc": "/recomendaciones/revision"
            },
            {
                "loc": "/testimonios/antes-y-despues"
            },
            {
                "loc": "/testimonios/programa-de-referidos"
            },
            {
                "loc": "/admin"
            },
            {
                "loc": "/noticias"
            },
            {
                "loc": "/procedimientos"
            },
            {
                "loc": "/simulador"
            },
            {
                "loc": "/testimonios"
            }
        ],
        "sourceType": "app"
    },
    {
        "context": {
            "name": "nuxt:route-rules",
            "description": "Generated from your route rules config.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:route-rules'] }`."
            ]
        },
        "urls": [
            "/",
            "/nosotros",
            "/simulador",
            "/recursos"
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
