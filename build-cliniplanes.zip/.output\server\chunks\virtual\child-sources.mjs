const sources = {
    "es-CO": [],
    "en-US": [],
    "pt-BR": []
};

export { sources };
//# sourceMappingURL=child-sources.mjs.map
