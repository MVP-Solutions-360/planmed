const sources = [
    {
        "context": {
            "name": "@nuxtjs/i18n:pages",
            "description": "Generated from your i18n.pages config.",
            "tips": [
                "You can disable this with `autoI18n: false`."
            ]
        },
        "urls": [
            {
                "_sitemap": "en-US",
                "loc": "en/about-us",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "en/about-us"
                    },
                    {
                        "hreflang": "pt-BR",
                        "href": "pt/sobre-nos"
                    }
                ]
            },
            {
                "_sitemap": "pt-BR",
                "loc": "pt/sobre-nos",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "en/about-us"
                    },
                    {
                        "hreflang": "pt-BR",
                        "href": "pt/sobre-nos"
                    }
                ]
            },
            {
                "_sitemap": "en-US",
                "loc": "en/resources",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "en/resources"
                    },
                    {
                        "hreflang": "pt-BR",
                        "href": "pt/recursos"
                    }
                ]
            },
            {
                "_sitemap": "pt-BR",
                "loc": "pt/recursos",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "en/resources"
                    },
                    {
                        "hreflang": "pt-BR",
                        "href": "pt/recursos"
                    }
                ]
            },
            {
                "_sitemap": "en-US",
                "loc": "en/simulator",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "en/simulator"
                    },
                    {
                        "hreflang": "pt-BR",
                        "href": "pt/simulador"
                    }
                ]
            },
            {
                "_sitemap": "pt-BR",
                "loc": "pt/simulador",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "en/simulator"
                    },
                    {
                        "hreflang": "pt-BR",
                        "href": "pt/simulador"
                    }
                ]
            }
        ],
        "sourceType": "app"
    },
    {
        "context": {
            "name": "nuxt:route-rules",
            "description": "Generated from your route rules config.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:route-rules'] }`."
            ]
        },
        "urls": [
            "/",
            "/nosotros",
            "/simulador",
            "/recursos"
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
