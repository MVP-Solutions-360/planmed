import { z as defineEventHandler, A as sitemapIndexXmlEventHandler } from '../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import 'node:crypto';

const sitemap_index_xml = defineEventHandler(sitemapIndexXmlEventHandler);

export { sitemap_index_xml as default };
//# sourceMappingURL=sitemap_index.xml.mjs.map
