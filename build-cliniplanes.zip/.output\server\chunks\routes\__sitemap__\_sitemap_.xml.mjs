import { z as defineEventHandler, B as sitemapChildXmlEventHandler } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'consola';
import 'nuxtseo-shared/utils';
import 'node:crypto';

const _sitemap__xml = defineEventHandler(sitemapChildXmlEventHandler);

export { _sitemap__xml as default };
//# sourceMappingURL=_sitemap_.xml.mjs.map
